<div class="menu">
    <nav>
        <ul>
            <li>
				<a href="index.php" data-caption="Home">Home</a>
            </li>
			<li>
                <a href="reg_form.php" data-caption="Sign Up">Sign Up</a>
            </li>												
            <li>
				<a href="emergancy_contact.php" data-caption="Contacts">Contacts</a>
            </li>
            <li class="list-item--active">
                <a href="aboutus.php" class="active" data-caption="About Us">About Us</a>
            </li>			         
        </ul>
	</nav>
</div>