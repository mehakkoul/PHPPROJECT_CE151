<div class="menu">
    <nav>
        <ul>
            <li class="list-item--active">
				<a href="index.php" class="active" data-caption="Home">Home</a>
            </li>
			<li>
                <a href="reg_form.php" data-caption="Sign Up">Sign Up</a>
            </li>												
            <li>
				<a href="emergancy_contact.php" data-caption="Contacts">Contacts</a>
            </li>
            <li>
                <a href="aboutus.php" data-caption="About Us">About Us</a>
            </li>			         
        </ul>
	</nav>
</div>