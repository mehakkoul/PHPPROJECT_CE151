<?php
$conn = mysql_connect("localhost", "root", "") or die("Error");
mysql_select_db("crimejk") or die("Error in selecting database");
?>
