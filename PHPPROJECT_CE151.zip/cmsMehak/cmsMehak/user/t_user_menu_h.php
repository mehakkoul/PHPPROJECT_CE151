<div class="menu">
                <nav>
                    <ul>
                        <li class="list-item--active">
                            <a href="index.php" class="active" data-caption="Home">Home </a>
                        </li>
                        <li>
                            <a href="firReport.php" data-caption="FIR">FIR</a>
                        </li>
                        <li>
                            <a href="criminalform.php" data-caption="Criminal Register">Criminal </a>
                        </li>
                        <li>
                            <a href="postmortem.php" data-caption="PostMortem">PostMortem</a>
                        </li>
                        <li>
                            <a href="wanted.php" data-caption="Most Wanted">Most Wanted</a>
                        </li>
                        <li>
                            <a href="suspect.php" data-caption="Suspect">Suspect</a>
                        </li>
                        <li>
                            <a href="search.php" data-caption="Search">Search</a>
                        </li>
                        <li>
                            <a href="logout.php" data-caption="Logout">Logout</a>
                        </li>
                    </ul>
                </nav>
            </div>