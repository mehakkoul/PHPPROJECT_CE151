<div class="footer">
            <center>
                <span>Crime Reporting of Jammu and Kashmir  &copy; 2021 </span><br>
                <span> <strong >Developed By :</strong> <a href="#">MEHAK KOUL</a> </span>
            </center>
</div><!--style="color:#0000FF " -->