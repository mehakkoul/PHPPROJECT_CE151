<div class="menu">
	<nav>
        <ul>
            <li>
                <a href="index.php" data-caption="Home">Home</a>
            </li>
            <li>
                <a href="add_user.php" data-caption="Add User">Add User</a>
            </li>
            <li>
                <a href="delete_user.php" data-caption="Delete User">Delete User</a>
            </li>
            <li>
                <a href="search_criminal.php" data-caption="Search">Search</a>
            </li>
            <li class="list-item--active">
                <a href="report.php"  class="active" data-caption="Report">Report</a>
            </li>
            <li>
                <a href="logout.php" data-caption="Logout">Logout</a>
            </li>
        </ul>
    </nav>
</div>