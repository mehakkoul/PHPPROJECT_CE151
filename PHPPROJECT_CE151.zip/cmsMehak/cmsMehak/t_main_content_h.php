<div class="row">
    <div style="padding:1px;">
        <table style="width:100%;">
            <tr>
                <td>
                    <div class="row">
                        <div class="col-md-2" style="background-color:aliceblue">
                            <img height="165" src="images/GST.jpg" />
                        </div>
                        <div class="col-md-8" style="background-color:aliceblue; text-align:justify">
                            <h3>
								<a href="article_GST.php" target="_blank" onmousedown="return   clk(this.href,'news_result','','res','1','','0CDAQqQIwAA')">
									GST revenue collection touch new high at Rs 1.23 lakh crore <em></em> 
								</a>
                            </h3>
							The gross Goods and Services Tax (GST) revenue collected in March was at a record of Rs 1.23 lakh crore, touching the highest level since its introduction, the government said on Thursday.
                            <br><br>
                            <a class="btn btn-default pull-right" href="article_GST.php" target="_blank">Read More</a>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td style="padding-top:30px;">
                    <div class="row">
                        <div class="col-md-2" style="background-color:aliceblue">
                            <img height="165" src="images/modi.jpg" />
                        </div>
                        <div class="col-md-8" style="background-color:aliceblue; text-align:justify">
                            <h3>
								<a href="article_narendramodi.php" target="_blank" onmousedown="return   clk(this.href,'news_result','','res','1','','0CDAQqQIwAA')">India's National Education Policy is futuristic: Modi <em>Narendra Modi</em></a></h3>
                                    Prime Minister Narendra Modi on Wednesday said the new National Education Policy is futuristic and as per world standards, and aimed at fulfilling Dr S Radhakrishnan's vision of education that empowers a student to participate in national development.
									
                                    <br><br>
                                    
									<a class="btn btn-default pull-right" href="article_narendramodi.php" target="_blank">Read More</a>
                        </div>
                    </div>
                </td>
            </tr>
            <tr>
                <td style="padding-top:30px;">
                    <div class="row">

						<div class="col-md-2" style="background-color:aliceblue">
							<img height="165" src="images/crimegraph.jpg" />
						</div>

						<div class="col-md-8" style="background-color:aliceblue; text-align:justify">
							<h3>
								<a href="article_crimeGraph.php" target="_blank" onmousedown="return   clk(this.href,'news_result','','res','1','','0CDAQqQIwAA')">Crime graph of Jammu</a></h3>
										Around 71 cases of NDPS Act are registered against 37 registered until September 31, 2014, which shows that the smuggling of psychotropic substances has increased more than twice in the Jammu district in the nine months period of 2015.
									<br><br>
								<a class="btn btn-default pull-right" href="article_crimeGraph.php" target="_blank">Read More</a>
						</div>
					</div>
                </td>
			</tr>
		</table>
	</div>                    

</div>