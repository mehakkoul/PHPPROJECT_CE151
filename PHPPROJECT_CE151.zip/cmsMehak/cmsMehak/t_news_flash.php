<div style="background-color:antiquewhite; border: 2px solid red; padding: 2px;">
          <div style="text-align:center;background-color:cornsilk"><p style="height:20px"><strong>NewsFlash</strong> </p></div>
          <div style="background-color:white; padding: 10px;">
              <center>

                  <marquee direction="up" style="height:220px">
                      <div class="newsticker-jcarousellite">
						<ul>
							<li>
								<div class="thumbnail">
									<img src="images/news1.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/shopkeepers-protest-against-delayed-road-work/">Shopkeepers protest against delayed road work</a>
										<span class="cat">Category: Protest</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>

							<li>
								<div class="thumbnail">
									<img src="images/news2.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/jammu-and-kashmir-schools-to-remain-closed-till-april-30/">Jammu and Kashmir Govt orders closure of schools, coaching centres till April 30</a>
										<span class="cat">Category: Education Infra</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>
							<li>
								<div class="thumbnail">
									<img src="images/news3.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/cobra-jawan-rakeshwar-singh-manhas-kidnapped-by-naxals-during-bijapur-attack-on-april-3-has-been-released/">Abducted CRPF commando Rakeshwar Singh Manhas released by Naxals .</a>
										<span class="cat">Category: Militancy</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>
							<li>
								<div class="thumbnail">
									<img src="images/news4.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/jk-prepares-for-largest-amarnath-yatra-with-an-expected-footfall-of-6-lakh-yatris/">J&K prepares for largest Amarnath Yatra with an expected footfall of 6 lakh yatris</a>
										<span class="cat">Category: Amarnath Yatra</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>
							<li>
								<div class="thumbnail">
									<img src="images/news5.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/woman-spo-from-kulgam-arrested-terminated-from-services-for-glorifying-militancy/"> Woman SPO arrested for ‘glorifying terrorism’ in Jammu and Kashmir’s Kulgam</a>
										<span class="cat">Category: Security Issue</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>
							<li>
								<div class="thumbnail">
									<img src="images/news6.jpg"><div class="info">
										<a href="https://www.dailyexcelsior.com/jk-integral-part-of-india-external-interference-not-acceptable-naidu/">J&amp;K integral part of India, external interference not acceptable: Naidu</a>
										<span class="cat">Category: Integral Part of India</span>
									</div>
								</div>

								<div class="clear"></div>
							</li>
						</ul>
                      </div>
                  </marquee>
              </center>
          </div>
      </div>